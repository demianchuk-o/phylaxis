"""A wheel is never analysed: invariant 2."""

__version__ = "1.0"
