# inert fixture payload; if this file ever appears outside the extraction
# root, path validation failed.
