from setuptools import setup

setup(name="tar-slip", version="1.0")
